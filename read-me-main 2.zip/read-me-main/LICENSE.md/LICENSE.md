i want to learn how to code
